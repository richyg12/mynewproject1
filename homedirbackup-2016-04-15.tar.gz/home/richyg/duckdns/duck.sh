

echo url="https://www.duckdns.org/update?domains=beduffpreppers&token=eeb05db4-c04c-4215-9526-87b4334e25c5&ip=" | curl -k -o ~/duckdns/duck.log -K -
