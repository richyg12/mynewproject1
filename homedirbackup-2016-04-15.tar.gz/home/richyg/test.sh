

## # # # # # # # # !/bin/bash

# system_page - A script to produce a system information HTML file

##### Constants

TITLE="Server $HOSTNAME"
RIGHT_NOW=$(date +"%d/%m/%y %R:%S")
TIME_STAMP="run at $RIGHT_NOW USER $USER"
MESSAGETYPE="$1"
##### Functions

function system_info
{
    echo "An Interface Error Has Occured"
    echo " Please refer to PDG"

}   # end of system_info


function show_uptime
{
    echo "Uptime:"
    uptime
}   # end of show_uptime


function drive_space
{
    echo "<h2>Filesystem space</h2>"
    echo "<pre>"
    df
    echo "</pre>"

}   # end of drive_space


function errtest
{
    #  comment

    if [ $MESSAGETYPE = "ERROR" ]; then
	echo $(system_info)  
    fi
    if [ $MESSAGETYPE != "ERROR" ]; then
        echo   "false alarm" 
    fi
}   # end of home_space



##### Main

echo  $TITLE $TIME_STAMP $1 $2 $3  $(errtest)  >> error.txt
#echo $(errtest)

