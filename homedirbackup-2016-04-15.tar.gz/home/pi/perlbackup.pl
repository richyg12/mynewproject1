#!/usr/bin/perl
@timeStampTmp=localtime();
$timeStampFinal=sprintf("%04d-%02d-%02d", 
$timeStampTmp[5]+1900,$timeStampTmp[4]+1,$timeStampTmp[3]);
chomp $timeStampFinal;
$maxAgeInMins=1440; # Backups older than this value (in days) will be deleted.
$backupDir='/USBStick/backups'; # This is where your backup archives/tarballs will go.
$dirToBackup='/home'; # This is the directory to be backup.
$backupFilePrefix='homedirbackup'; # Format of backup filename is "<$backupFilePrefix>-<$timeStampFinal>.tar.gz". Note that the whole absolute path ( except for the leading "/" ) will be stored in your archive/tarball.
$command='tar czpf '.$backupDir.'/'.$backupFilePrefix.'-'.$timeStampFinal.'.tar.gz '.$dirToBackup.' > /dev/null 2>&1';
system($command);
$command='find '.$backupDir.' -maxdepth 9 -type f -mmin +'.$maxAgeInMins.' -exec rm -f {} \;';
print $command;
system($command);

